let a;
let b = 7;
let c = null; // nil
let d = 0;

console.log(a, b, c);
console.log(a + b);
console.log(b + c + 1);
console.log(b + d + 1);