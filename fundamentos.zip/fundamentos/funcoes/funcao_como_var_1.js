const x = 123;
let y = 321;

const somar = function (a, b) {
    return a + b;
}

console.log(somar(x, y));