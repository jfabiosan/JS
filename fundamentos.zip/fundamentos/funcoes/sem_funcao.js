const d1 = 3;
const m1 = 7;
const a1 = 2021;

console.log(`Dia: ${d1}`);
console.log(`Mês: ${m1}`);
console.log(`Ano: ${a1}`);

const d2 = 23;
const m2 = 12;
const a2 = 2022;

console.log(`Dia: ${d2}`);
console.log(`Mês: ${m2}`);
console.log(`Ano: ${a2}`);