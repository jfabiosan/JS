const numeros = [1, 2, 356, 4, 5, 6, 11, 45];

for(let i = 0; i < numeros.length; i++) {
    console.log(numeros[i]);
}

for(let i = 1; i < numeros.length; i += 2) {
    console.log(numeros[i]);
}