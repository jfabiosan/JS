const numeros = [1, 2, 3, 4, 5, 8];

numeros.splice(1, 2);
console.log(numeros);

console.log(numeros.pop());
console.log(numeros.pop());
console.log(numeros);