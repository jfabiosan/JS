console.log(typeof console);
console.log(typeof console.log);

const numeros = [1, 2, 3];

console.log(typeof numeros);

numeros.push(4);
numeros.push(5);
numeros.push(10.98);

console.log(numeros);
console.log(numeros.length);