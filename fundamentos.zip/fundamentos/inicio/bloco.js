{
    console.log("Passo #01");
    console.log("Passo #02");
    console.log("Passo #03");
}

{
    console.log("Passo #04");
    console.log("Passo #05");
}

{
    {
        {
            {
               ;
               ;
               ; 
            }
        }
    }
}

console.log("Fim!");