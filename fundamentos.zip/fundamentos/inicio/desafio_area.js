const PI = 3.141592;
const raio = 10;
let areaCirc = PI * raio * raio;

console.log("O valor da área é " + areaCirc + "m2.");

areaCirc = Math.PI * raio * raio;
console.log("O valor da área é " + areaCirc + "m2.");