const a = 3;

// ...

// a = a + 10;

// ...

console.log(a);