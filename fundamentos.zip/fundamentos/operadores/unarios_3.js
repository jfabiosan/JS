console.log(!!true);
console.log(!!false);

console.log(!!'Texto!');
console.log(!!"");

console.log(!!1);
console.log(!!0);
console.log(!!-1);
console.log(!!-0.00001);