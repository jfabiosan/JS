let f = 73;
let c = (f - 32) / 9 * 5;
console.log(c);