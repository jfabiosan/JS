let texto = 'Lista de Aprovados\n';
texto += '==================\n\n';
texto += '1. Ana Silva\n';
texto += '2. Pedro Albuquerque\n';
texto += '3. Guilherme Pereira\n';
texto += '4. Rebeca França\n';

console.log(texto);