let a = 1;
let b = "1";
let c = "1";

console.log(a == b);
console.log(a === b);
console.log(b === c);

console.log(a != b);
console.log(a !== b);
console.log(b !== c);