let a = 1;
let b = 2;

// encontre 5 expressões que o resultado é TRUE
console.log(a < b);
console.log(a <= b);
console.log(a != b);
console.log(a !== b);
console.log(a + a === b);

// encontre 5 expressões que o resultado é FALSE
console.log(a > b);
console.log(a >= b);
console.log(a == b);
console.log(a === b);
console.log(a + a !== b);