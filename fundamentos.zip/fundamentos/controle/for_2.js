// for(;;) {
// }

// for(; true; ) {
// }

let controle = 1;

for (; controle <= 10;) {
    console.log(controle);
    controle++;
}

console.log('Fim!');