const nota = 2.3

if (nota >= 9) {
    console.log('Quadro de Honra!')
    console.log('Parabéns!')
}

console.log('Fim!')