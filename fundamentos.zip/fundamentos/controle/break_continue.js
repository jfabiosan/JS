// break
for(let i = 1; i <= 5; i++) {
    if(i === 3) {
        break;
    }
    console.log(i);
}

// continue
for(let i = 1; i <= 5; i++) {
    if(i === 3) {
        continue;
    }
    console.log(i);
}