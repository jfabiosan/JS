const nota = 8;
const bomComportamento = true;

if (nota >= 7 && bomComportamento)
    console.log('Parabéns!');

if (nota < 7 || !bomComportamento)
    console.log('Uma pena!');

console.log('Fim!')