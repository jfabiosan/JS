for (let controle = 1; controle <= 10; controle++) {
    console.log(controle);
}

console.log('Fim!');
