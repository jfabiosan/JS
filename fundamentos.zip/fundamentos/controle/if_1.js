if (true)
    console.log('Vai ser executado!');

if (false)
    console.log('Não vai ser executado!');

console.log('Fim!');