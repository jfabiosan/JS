const nota = 9.99;

if (nota <= 10 && nota >= 9)
    console.log('A');

if (nota < 9 && nota >= 7)
    console.log('B');

if (nota < 7 && nota >= 5)
    console.log('C');

if (nota < 5 && nota >= 4.5)
    console.log('D');

if (nota >= 0 && nota < 4.5) {
    console.log('F');
}